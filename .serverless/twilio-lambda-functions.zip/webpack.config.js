module.exports = {
    target: 'node',
    mode: 'production',
};
