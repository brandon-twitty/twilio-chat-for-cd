# twilio-serverless

sls deploy from root directory for everything else look up serverless framework docs and AWS docs (even tho wrong sometimes) 

Twilio has good docs but if not covered by their SLA be cautious 
