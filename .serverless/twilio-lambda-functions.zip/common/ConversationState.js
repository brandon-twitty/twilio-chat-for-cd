exports.UNACCEPTED = "UnAccepted";
exports.ACCEPTED = 'Accepted';
exports.EXPIRED = 'Expired';